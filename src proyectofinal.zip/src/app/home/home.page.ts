import { Component, OnInit } from '@angular/core';
import { AuthService } from '@auth0/auth0-angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  public user: any;

  constructor(public auth: AuthService) { }

  ngOnInit() {

    this.auth.user$.subscribe((data) =>{
    this.user = data
    console.log(this.user);

    //to do: post user to backend


  });
    
  }

}
