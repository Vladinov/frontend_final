import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-preguntas',
  templateUrl: './preguntas.page.html',
  styleUrls: ['./preguntas.page.scss'],
})
export class PreguntasPage implements OnInit {
  public preguntas: any;
  public random: any;
  public oba: any;
  public respuestas: any;


  constructor(private route: ActivatedRoute, private http: HttpClient) { }

  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      let tema = JSON.parse(params['tema']);
      console.log(tema)


      this.http.get('http://localhost:3000/preguntas/' + tema.id).subscribe((response) => {
        console.log(response);
        this.preguntas = response;

        this.random = Math.floor(Math.random() * this.preguntas.length);
        console.log(this.random)
        this.oba = this.preguntas[this.random];

        this.http.get('http://localhost:3000/respuestas/' + this.oba.id).subscribe((response) => {
          console.log(response);
          this.respuestas = response;
    }
    )
      }
      )

    }
    );
  }


}
