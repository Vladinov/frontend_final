import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-preguntas',
  templateUrl: './preguntas.page.html',
  styleUrls: ['./preguntas.page.scss'],
})
export class PreguntasPage implements OnInit {
  public preguntas: any;
  public random: any;
  public oba: any;
  public respuestas: any= [];
  public respuestacorrecta: any;
  public respuestaSeleccionada: string = '';
  public respuesta_seleccionada = '';



  constructor(private route: ActivatedRoute, private http: HttpClient, private router : Router) { }

  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      let tema = JSON.parse(params['tema']);
      console.log(tema)


      this.http.get('http://localhost:3000/preguntas/' + tema.id).subscribe((response) => {
        console.log(response);
        this.preguntas = response;

        this.random = Math.floor(Math.random() * this.preguntas.length);
        console.log(this.random)
        this.oba = this.preguntas[this.random];

        this.http.get('http://localhost:3000/respuestas/' + this.oba.id).subscribe((response:any) => {
          console.log(response);
          console.log("Respuesta correcta")
        this.respuestacorrecta = response[0].respuesta_correcta;
        console.log(this.respuestacorrecta)
          this.respuestas = [];
          this.respuestas.push(response[0].respuesta_correcta);
          this.respuestas.push(response[0].respuesta_incorrecta_1);
          this.respuestas.push(response[0].respuesta_incorrecta_2);
          this.respuestas.push(response[0].respuesta_incorrecta_3);
          this.sortAnswers();
        })
      })

    });
  }

  sortAnswers() {
    this.respuestas = this.respuestas.sort(() => 0.5 - Math.random());
  }

  responderPregunta(respuesta: string){
    this.respuesta_seleccionada = respuesta;
  }

  VoF( respuestaSeleccionada: string){

    if(this.respuesta_seleccionada != ''){
      if( respuestaSeleccionada == this.respuestacorrecta ){
        return "verde"
      }
      else {
        return "rojo"
      }
    }
    return '';
  }

  goInicio() {
    this.router.navigate(
      ['/home'],
    );
  }

  goRuleta() {
    this.router.navigate(
      ['/ruleta'],
    );
  }
 
}
